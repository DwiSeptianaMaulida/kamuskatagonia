Language : Indonesia/Bahasa
Author : Dwi Septiana Maulida
Lisensi : Limited User

Library yang Harus Diinstall :
KGradient Panel

#Aplikasi ini harus tersambung ke internet
